#include <math.h>
#include <stdio.h>
#include <stdlib.h>

double dtw(double *x, double *y, int xsize, int ysize, double window_frac);
// int *dtw_path(double *x, double *y, int xsize, int ysize, double window_frac);
