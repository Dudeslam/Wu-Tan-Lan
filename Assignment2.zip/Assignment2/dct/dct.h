#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void DCTII(size_t, size_t, float *, const float *);
